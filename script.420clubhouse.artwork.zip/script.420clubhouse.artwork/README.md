# change the following foldernames to what ever you want to 
lib\abcartartwork
lib\abdartartwork
lib\abeartartwork
or remove the ones you dont want 
also rename 
resources\media\abc 
resources\media\def
resources\media\ghi
resources\media\jkl
resources\media\mno
to whatever you want 
